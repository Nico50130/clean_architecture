
class StatementEntity {
  final String value;
  StatementEntity(this.value);
}